# Task Management Simulator (WIP)
#### An RPG-styled web app for your time management needs!

## Installation instructions:

1. Install node and npm on machine 
2. `npm install` from root directory that has package.json
3. `npm start` to start server that automatically refreshes on changes 
4. Open browser and go to localhost:3000

-------------------------------------------------------

## Currently working on: Character Page

- My work so far can be found in: `brandon_test/docs/examples/theme`

- Testing on Firefox

## Screenies:

![Alt text](screenie.png?raw=true "Screenshot")